<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>


## **CONFIGURAÇÃO DOS ALERTAS DE DISPONIBILIDADE GERAL DAS APIS E COMPONENTES DE INFRA**
 
Este roteiro tem como objetivo orientar a configuração de alertas de disponibilidade das APIs e componentes de infra.

Os alertas são notificações enviadas para um e-mail configurado no **Alertmanager** de acordo com a regras configuradas para cada tipo de alerta.

A descrição de cada alerta estão descritos na seção **Descrição dos Alertas** deste roteiro.


### **PRÉ-REQUISITOS:**
 
- Prometheus, Grafana e Alertmanager em funcionamento no cluster;
- Conta de e-mail para recebimento dos alertas;
- Ferramenta de comando Kubectl instalada.
 
:warning: *Aviso*
 
- Este roteiro leva em consideração que o contexto do seu terminal está definido dentro da pasta *../instalacao/alertas/* deste roteiro.

- O passo inicial irá configurar o **Alertmanager** para enviar alertas via e-mail. **Caso o componente Alertmanger** do seu ambiente já estiver configurado e enviando alertas via e-mail de outras aplicações, pule esta etapa e vá para o passo **1.3**.
 

## **1 - CONFIGURAR O ALERTMANAGER**

O AlertManager é o componente responsável por gerar notificações quando as ocorrências acontecem baseadas nas regras de alertas configuradas.
 
Essas configurações devem ser aplicadas no mesmo namespace em que o Prometheus e Grafana estão sendo executados.


1.1 - Abra e edite o arquivo **alertmanager.yaml**, informando os seguintes dados nas seções conforme o exemplo abaixo:
 
![](../../img/email-alert2.png)
 
 
- [1]: **send_resolved:** Envia um e-mail informando que um problema alertado foi resolvido. Defina como *false* para não enviar este e-mail ou *true* para enviar.

 
- [2]: Informe as configurações de e-mail conforme descrito abaixo:
 
 - **to:** Endereço de e-mail que receberá os alertas;
 
 - **from:** Endereço de e-mail que enviará os alertas;
 
 - **smarthost:** Servidor SMTP e a porta do serviço;
 
 - **auth_username:** Usuário de autenticação do e-mail (remover este parâmetro caso não houver);
 
 - **auth_password:** Senha de autenticação do usuário (remover este parâmetro caso não houver);
 
 - **require_tls:** Defina como *true* caso o servidor SMTP usar autenticação TLS ou *false* para não usar.
 

- [3]: **headers.Subject:** Caso queira identificar no assunto da mensagem de e-mail o ambiente a qual o alerta enviado pertence, substitua o nome *Ambiente* informando o ambiente em que o AlertManager está sendo configurado. Ex: Produção, Homologação, etc... Caso não queira esta identificação, remova **Ambiente -** deixando apenas o valor **'{{ template "email.default.subject" . }}'**
 

- [4]: **routes:** Defina os intervalos de tempo desejados para o envio dos e-mails de alertas:
 
 - **group_wait:** Quanto tempo esperar inicialmente para enviar uma notificação para um grupo de alertas. Permite esperar que um alerta de inibição chegue ou receba mais alertas iniciais para o mesmo grupo. Valor default em segundos: **10s**
 - **group_interval:** Quanto tempo esperar antes de enviar uma notificação sobre novos alertas que são adicionados a um grupo de alertas para os quais uma notificação inicial já foi enviada. Valor default em minutos: **10m**
 - **repeat_interval** Quanto tempo esperar antes de reenviar um determinado alerta que já foi enviado em uma notificação por e-mail. Valor default em horas: **1h**
 

1.2 - Atualize o secret `alertmanager-prometheus-operator-kube-p-alertmanager` existente no ambiente com os comandos abaixo (executar um comando de cada vez):

```bash
kubectl delete secret alertmanager-prometheus-operator-kube-p-alertmanager -n monitoramento
 
kubectl create secret generic alertmanager-prometheus-operator-kube-p-alertmanager --from-file=alertmanager.yaml -n monitoramento
```

- Desta forma,  as configurações do alertmanager ficarão em um objeto Secret do Kubernetes.
 

1.3 - Aplique o arquivo de configuração dos alertas com o comando kubectl conforme o exemplo abaixo:
 
```bash
kubectl apply -f alert-rules-geral.yaml -n monitoramento
```
 
## **2 - DESCRIÇÃO DOS ALERTAS**

Essa seção descreve os alertas que serão emitidos ao Alertmanager e posteriormente enviados ao e-mail cadastrado.

**Grupo: geral.application.rules**
 
- **Aplicacao_Indisponivel:** *[Severidade Critical]* - O alerta será enviado quando alguma API ficar indisponível no ambiente por **15 segundos**;

- **Redis_Indisponivel:** *[Severidade Critical]* - O alerta será enviado quando algum pod  do redis ficar indisponível no ambiente por **15 segundos**;

- **Kafka_Indisponivel:** [Severidade Critical] -  O alerta será enviado quando algum pod  do Kafka ficar indisponível no ambiente por **15 segundos**;

- **Zookeeper_Indisponivel** [Severidade Critical] - O alerta será enviado quando algum pod  do zookeeper ficar indisponível no ambiente por **15 segundos**;
 
- **Vault_Indisponivel** [Severidade Critical] - O alerta será enviado quando algum pod  do vault ficar indisponível no ambiente por **15 segundos**;


### **EXEMPLO DA MENSAGEM DE ALERTA RECEBIDA NO E-MAIL**
 
Com os alerts rules e o alertmanager configurados, as notificações dos alertas serão enviados ao e-mail cadastrado no alertmanager. A mensagem de email será enviada com as informações conforme o exemplo abaixo:
 
- **Assunto:** [FIRING:4] Aplicacao_Indisponivel (monitoramento/prometheus-operator-kube-p-prometheus email critical)
 
- **Mensagem:** 100% da aplicaçao api-df-arquivos no namespace autbank-df está indisponível.
 
Exemplo do corpo da mensagem do email do alerta de API:
 
![](../../img/email-alert3.png)


## EXTRA (OPCIONAL)
 
### SILENCIAR ALERTAS NO ALERTMANAGER

Os alertas enviados pelo alertmanager podem ser desativados **caso for desejado**.
Para silenciar os alertas, siga os passos descritos abaixo.

:warning: **Aviso**:
 
- O procedimento abaixo irá silenciar alertas, ou seja, não serão enviadas mensagens de e-mails referente ao alerta silenciado desejado. A partir da aplicação desta configuração,  é importante **sempre lembrar que existem alertas silenciados configurados** no AlartManager do ambiente para que não interfira futuramente no envio de mensagens de alertas. Contudo, verifique os alertas que estão silenciados e **desative-os sempre que necessário**.

- A instrução para efetuar a desativação, está orientada neste roteiro.
 
 
### ATIVAR O SILENCE

1 - Em um navegador Web, acesse a interface do **AlertManager** do seu ambiente. Normalmente, fica no endereço e porta: http://endereco-do-alertmanger:30122.

2 - Na página do AlertManager, em **Alerts**, será exibido todos os alertas ativados que contém alertas. Localize o alerta que queira silenciar e clique no ícone **+** localizado ao lado esquerdo do alerta conforme mostra o exemplo:

![](../../img/alert-1.png)

3 - Para silenciar o alerta, clique em **Silence**:

![](../../img/alert-2.png)

4 - Em seguida, será exibida a página de configuração do **New Silence**. Escolha o período em que este silence ficará ativo. A configuração deverá ser feita da seguinte maneira:

- **Start**: Inicio do Silence para ser ativado;
- **Duration**: Duração do silence em tempo;
- **End**: Fim do silence (quando chega ao fim, os alertas serão retomados e enviados ao e-mail)

4.1 - Escolha o período em que deseja que este silence fique ativo [1]. Dica: Configurando apenas o **End**, o campo de **Duration** é calculado automaticamente.

4.2 - No campo **Creator** [2], insira um nome, em **Comment** [3] coloque um comentário e por fim crie o silence clicando em **Create** [4], conforme mostra o exemplo:

![](../../img/alert-4.png)

5 - Será exibida a confirmação do silence criado com o **State = active**.
![](../../img/alert-5.png)

## DESATIVAR O SILENCE

1 - Para desativar manualmente o silence de um alerta, na página do Alertmanager, clique na guia **Silences** e em seguida localize o alerta que queira desativar e após clique em **Expire**, conforme mostra o exemplo:

![](../../img/alert-6.png)

2 - Clique em **Confirm** na mensagem de confirmação de expiração do silence:
![](../../img/alert-7.png)
 
 
Com o silence desativado (expirado), os alertas serão enviados novamente por e-mail.
