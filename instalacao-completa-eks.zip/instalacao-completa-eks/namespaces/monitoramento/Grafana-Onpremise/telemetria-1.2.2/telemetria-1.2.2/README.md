<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

# *Instalação da APM e Logs*

Este roteiro descreve os passos necessários para efetuar a instalação de todos os componentes ligados a APM e coleta de logs.

## Módulos

Os itens abaixo devem ser instalados na mesma sequência que são descritos para que a instalação seja efetuada com sucesso.

:warning: Cada módulo tem seu próprio documento de instalação que será descrito em cada item, por favor se atente as indicações de caminhos e diretórios informados.

:warning: A adição do OpenTelemetry agent pode aumentar o tempo de startup das aplicações entre 10 e 20 segundos por conta da instrumentação realizada antes do inicio da aplicação.

### Elastic Search

Esse módulo é usado para persistência das informações geradas pela APM e Logs.

Para instalá-lo siga o roteiro presente no diretório **elasticsearch/README-ELASTICSEARCH.pdf**

### Kibana

Esse módulo é utilizado para visualizar os logs, métricas do elastic search e informações adicionais da APM.

Para instalá-lo siga o roteiro presente no diretório **kibana/README-KIBANA.pdf**

### MetricBeat

Este módulo é utilizado para coletar as métricas do Elastic Search, sendo de extrema importância para o monitoramento do mesmo.

Para instalá-lo siga o roteiro presente no diretório **elasticsearch/README-METRIC_BEAT.pdf**

### FileBeat

Este módulo tem a função de coletar os logs distribuídos entre os hosts do Kubernetes e enviá-los ao Elastic Search a fim de persistir as informações e facilitar a leitura dos logs.

Para instalá-lo siga o roteiro presente no diretório **logs/README-FILE_BEAT.pdf**

### OpenTelemetry Collector Agent

Este módulo tem a função de coletar as informações de telemetria lançado pelas aplicações e enviá-los a um backend de trace distribuído (jaeger no nosso caso).

Para instalá-lo siga o roteiro presente no diretório **apm/README-OPENTELEMETRY_COLLECTOR.pdf**

### Jaeger

Este é o módulo que receberá e agregará as informações relacionadas ao trace distribuído salvando essas informações no Elastic Search e permitindo a consulta dos traces em sua interface.

Para instalá-lo siga o roteiro presente no diretório **apm/README-JAEGER.pdf**


## Adicionando Java Agent as aplicações

Neste passo será utilizado um [volume empty dir](https://kubernetes.io/docs/concepts/storage/volumes/#emptydir) que tem seu ciclo de vida associado ao pod, este volume é utilizado para conter o jar do Java Agent que será utilizado pela aplicação.

**Um exemplo completo pode ser encontrado em apm/java-agent-exemplo/api-pagamento-instantaneo-deployment.yml**

1 - Adicione o init container

```yaml
      initContainers:
      - name: get-apm-agent
        image: gcr.io/autbank/arquitetura/opentelemetry-agent:1.1.0
        command: ['sh', '-c', "cp /opentelemetry-jar/opentelemetry-javaagent-all.jar /jars/opentelemetry-javaagent-all.jar"]
        volumeMounts:
        - mountPath: /jars
          name: jars-volume
```

2 - Adicione o volumeMount no container da aplicação

```yaml
        volumeMounts:
        - mountPath: /jars
          name: jars-volume
```

3 - Adicione o volume ao pod

```yaml
      volumes:
      - name: jars-volume
        emptyDir: {}
```

4 - Adicione as variáveis de ambiente que configuram o Java agent, em `OTEL_RESOURCE_ATTRIBUTES` se atente em alterar o `service.name` de acordo com o nome da aplicação e `deployment.environment` com o nome do seu ambiente.

```yaml
        - name: JAVA_OPTS
          value: "-javaagent:/jars/opentelemetry-javaagent-all.jar"
        - name: OTEL_RESOURCE_ATTRIBUTES
          value: "service.name=api-pagamento-instantaneo,deployment.environment=hom,stack.app=spi"
        - name: OTEL_EXPORTER_OTLP_ENDPOINT
          value: "http://otlp-collector-agent.telemetria:55680"
        - name: OTEL_METRICS_EXPORTER
          value: "none"
        - name: OTEL_INSTRUMENTATION_OKHTTP_ENABLED
          value: "FALSE"
        - name: OTEL_INSTRUMENTATION_LETTUCE_ENABLED
          value: "FALSE"
```

5 - Adicione as variáveis abaixo que configuram a porcentagem de transações enviadas à APM, a env `OTEL_TRACES_SAMPLER_ARG` pode ter valores entre [0..1] sendo 1 o mesmo que enviar 100% dos traces, nesse ponto devemos ter muita atenção a quantidade de transações realizadas em nosso ambiente pois se o número de transações dentro de um período for maior que a quantidade que pode ser gravada no Elastic Search pode haver perda de dados de telemetria.


```yaml
        - name: OTEL_TRACES_SAMPLER
          value: "parentbased_traceidratio"
        - name: OTEL_TRACES_SAMPLER_ARG
          value: "1"
```

## Utilizando Jaeger

1 - Acesse o Jaeger Query, selecione o serviço e operação e clique em **Find Traces**

![](./assets/imgs/uso-jaeger-1.png)

2 - Selecione o trace que deseja visualizar

![](./assets/imgs/uso-jaeger-3.png)

3 - Agora você poderá ver todo o processo de execução da operação incluindo a comunicação entre serviços seja através de chamadas HTTP ou tópicos Kafka.

![](./assets/imgs/uso-jaeger-4.png)

## Compreendendo dashboard Kibana

1 - Acesse o Kibana, digite `trace` na busca e clique sobre **Trace SPI**

![](./assets/imgs/uso-elastic-1.png)

2 - Você conseguirá ver um gráfico como o abaixo:

![](./assets/imgs/uso-elastic-2.png)

2.1 - **Traces p/ serviço (%)**

Este gráfico demonstra a porcentagem de informações sobre telemetria coletada de cada aplicação.

2.2 - **Traces p/ serviço (Barra)**

Este gráfico demonstra a quantidade de informações sobre telemetria coletada de cada aplicação.

2.3 - **Operações SPI**

Esta lista apresenta a quantidade de operações realizadas no SPI por tipo de operação.

## Arquitetura de comunicação dos componentes


Nessa seção serão detalhados os componentes da solução de logs e trace e a arquitetura sugerida para instalação dos mesmos.


### Logs

![](./assets/imgs/arq-logs.png)

Essa solução conta basicamente com os três componentes exibidos na imagem, sendo eles:

- **1 - Filebeats**  - Esse componente deve ser instalado como um [DaemonSet](https://kubernetes.io/docs/concepts/workloads/controllers/daemonset/) e ter [volumes alocados diretamente no host](https://kubernetes.io/docs/concepts/storage/volumes/#hostpath) para que os logs gerados pelo docker em `/var/log/containers/` sejam enviados para o componentes o elastic search, dessa forma todos os logs gerados em todos os hosts podem ser enviados a um repositório único.

- **2 - Elastic Search** - Este será o banco de dados utilizado para armazenar as informações de Logs, é recomendado que esse componente seja instalado fora do Cluster para que não concorra por recursos com outras aplicações dessa forma performando melhor.

- **3 - Kibana** - Este componente pode ser instalado como um [deployment](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/) dentro do cluster, ele será basicamente nossa interface de visualização de logs.


### Trace Distribuído

![](./assets/imgs/arq-trace.png)

Essa solução conta com cinco componentes:


- **1 - Container de aplicação**  - Esses são os [deployments](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/) padrões, porém com a adição do [opentelemetry agent](https://github.com/open-telemetry/opentelemetry-java-instrumentation) para instrumentar as aplicações e enviar as métricas para o OpenTelemetry Collector Agent.

![](./assets/imgs/arq-trace-container.png)

- **2 - [OpenTelemetry Collector Agent](https://github.com/open-telemetry/opentelemetry-collector-contrib)**  - Esse componente é instalado no cluster Kubernetes como um [deployments](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/) escalado e toda a comunicação dos containers com ele é realizar através de um [service](https://kubernetes.io/docs/concepts/services-networking/service/) para garantir a resiliência. Sua função é basicamente coletar as informações de telemetria enviadas pelos containers e convertê-las para um backend, no nosso caso o Jaeger.

- **3 - Jaeger Collector**  - Esse componente segue o mesmo padrão do anterior sendo um  [deployment](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/) escalado e exposto através de um [service](https://kubernetes.io/docs/concepts/services-networking/service/). Sua função é coletar os dados enviados pelo OpenTelemetry Collector Agent, processar e consolidar as informações no Elastic Search para consultas futuras.


- **4 - Elastic Search** - Assim como na solução de Logs este será o banco de dados utilizado para armazenar as informações e pode inclusive ser a mesma instância, é recomendado que esse componente seja instalado fora do Cluster para que não concorra por recursos com outras aplicações dessa forma performando melhor.

- **5 - Jaeger Query** - Este é o componente que fornece uma interface Web para consulta dos traces, no desenho ele é apresentado em um host diferente das outras aplicações, mas na verdade se trata de um [deployment](https://kubernetes.io/docs/concepts/workloads/controllers/deployment/) simples e pode coexistir com os outros componentes sem problemas.

## Guia de Atualizações

#### 1.1.4 -> 1.1.5

- Siga o procedimento em **atualizações/1.1.5/README.pdf**

#### 1.1.5 -> 1.2.0

- Siga o procedimento em **atualizações/1.2.0/README.pdf**