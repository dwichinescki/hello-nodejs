<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

#  **INSTALAÇÃO E CONFIGURAÇÃO DO KIBANA**
 
O objetivo deste roteiro é instruir a instalação e configuração do **Kibana** dentro do cluster Kubernetes.
 
:warning: Este roteiro leva em consideração que o contexto do seu terminal está definido dentro da pasta **kibana** onde este documento se encontra.

### **PRÉ-REQUISITOS:**

- Instância do Elasticsearch instalada e em funcionamento;
- Acesso ao kubectl para aplicação de novos objetos do Kubernetes.

1 - Crie o namespace **telemetria**

```bash
kubectl create namespace telemetria
```

2 - Adicionando autenticação ao ElasticSearch

2.1 - Em um terminal, converta  a senha do usuário *kibana_sistem* em base 64 substituindo o valor *senha_kibana* para a senha definida anteriormente:
 
```bash
echo -n 'senha_kibana' | base64
```

2.2 - Abra o arquivo **kibana-secrets.yaml** e na propriedade *data* do arquivo, edite o valor da key **elasticsearch-password** substituindo a senha atual no arquivo para a senha em base 64 gerada no passo anterior e salve o arquivo.


2.3 - Abra o arquivo **kibana.yaml** e na propriedade de *env*, altere o endereço do elastic search conforme sua instalação e salve o arquivo.

```yaml
env:
  - name: ELASTICSEARCH_HOSTS
    value: http://elasticsearch:9200
```

3 - Exposição 

Atualize o arquivo **kibana-service.yaml** alterando o `nodePort` caso desejar que a exposição seja realizada em uma porta diferente.

```yaml
spec:
  ports:
  - name: rest
    port: 5601
    protocol: TCP
    targetPort: 5601
    nodePort: 32500
  selector:
    app: kibana
  type: NodePort
```

4 - Faça o apply dos arquivos de instalação

```bash
kubectl apply -f kibana-secrets.yaml
kubectl apply -f kibana-service.yaml
kubectl apply -f kibana.yaml
```

**5 - CRIAR UM USUÁRIO NO KIBANA**

:warning: Este passo poderá ser feito posteriormente, após a conclusão da instalação e configuração de todos os modulos presente neste roteiro na ordem solicitada.

5.1 - Acesse a interface do Kibana e faça login com o usuário **elastic** informando a senha definida anteriormente:
 
![](../assets/imgs/kibana-user1.png)
 
 
5.2 - Clique em **Manage**:
 
 
![](../assets/imgs/kibana-user2.png)
 
5.3 - Em **Security**, clique em **Users**:
 
 
![](../assets/imgs/kibana-user3.png)
 
 
5.4 - Será exibido os usuários **built-in** do elasticsearch. Para adicionar um novo usuário clique em **Create user**:
 
 
![](../assets/imgs/kibana-user4.png)
 
 
5.5 - Adicione as informações de login para o novo usuário conforme exemplo:
 
 
![](../assets/imgs/kibana-user4-a.png)
 
 
5.6 - Mais abaixo, em **Privileges**, na lista de **Roles**, selecione a role **kibana_admin** e em seguida clique **Create User**
 
 
![](../assets/imgs/kibana-user4-b.png)
 
 
- O usuário criado será mostrado na lista de usuários.
 
- A role definida para este usuário tem a permissão de administrador do Kibana (role kibana_admin). Para mais informações sobre roles, consulte a documentação oficial sobre as [built-in-roles](https://www.elastic.co/guide/en/elasticsearch/reference/current/built-in-roles.html).
 
- Caso for necessário criar novas roles, consulte a documentação oficial sobre [kibana-role-management](https://www.elastic.co/guide/en/kibana/current/kibana-role-management.html#_required_permissions_9).