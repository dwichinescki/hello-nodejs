<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

#  **INSTALAÇÃO E CONFIGURAÇÃO DO JAEGER**
 
O objetivo deste roteiro é instruir a instalação e configuração do **Jaeger** dentro do cluster Kubernetes.
 
:warning: Este roteiro leva em consideração que o contexto do seu terminal está definido dentro da pasta **apm** onde este documento se encontra.

### **PRÉ-REQUISITOS:**

- Instância do Elasticsearch instalada e em funcionamento;
- Namespace `telemetria` deve ter sido criado anteriormente na instalação do Kibana;
- Acesso ao kubectl para aplicação de novos objetos do Kubernetes.


1 - Em um terminal, converta  a senha do usuário *elastic* em base 64 substituindo o valor *senha_elastic* para a senha definida anteriormente:
 
```bash
echo -n 'senha_elastic' | base64
```

1.1 - Abra o arquivo **jaeger/jaeger-secrets.yaml** e na propriedade *data* do arquivo, edite o valor da key **elasticsearch-password** substituindo a senha atual no arquivo para a senha em base 64 gerada no passo anterior e salve o arquivo.

1.2 - Para acessar o Jaeger Query precisaremos gerar um usuário e senha no formato [`.htpasswd`](https://pt.wikipedia.org/wiki/.htpasswd) para isso podemos usar uma das duas formas a seguir:

1.2.1 - Abra o site [https://www.web2generators.com/apache-tools/htpasswd-generator](https://www.web2generators.com/apache-tools/htpasswd-generator), adicione o usuário e senha que deseja para o acesso ao Jaeger Query e clique em *Generate .htpasswd file* e copie o valor presente em *Output*.

![](../assets/imgs/jaeger-1-2.png)

**Caso opte por essa forma pule o passo 1.2.2**

1.2.2 - Como alternativa podemos instalar o `httpd-tools` para gerar o hash, execute os comandos abaixo substituindo *admin* e *password* pelo usuário e senha que deseja para o acesso ao Jaeger Query e copie a saída do comando.

```bash
yum install httpd-tools -y

htpasswd -n -b admin password
```

1.3 - Crie um base64 do htpasswd com o comando abaixo, substituindo `htpasswd` pelo valor gerado no passo anterior:

```bash
echo -n 'htpasswd' | base64
```

1.4 - Abra o arquivo **jaeger/jaeger-secrets.yaml** e na propriedade *data* do arquivo, edite o valor da key **jaeger-auth** substituindo o valor pelo htpasswd em base64 gerado no passo anterior e salve o arquivo.

2 - Edite o arquivo **jaeger/jaeger-collector.yaml** ajustando o endereço do elastic search de acordo com sua instalação

```yaml
args:
  - "--es.server-urls=http://172.31.84.27:9200"
```


3 - Abra o arquivo **jaeger/jaeger-query.yaml** ajustando o endereço do elastic search de acordo com sua instalação

```yaml
args:
  - "--es.server-urls=http://172.31.84.27:9200"
```

4 - Aplique os novos objetos referentes ao Jaeger

```bash
kubectl apply -f jaeger/jaeger-secrets.yaml
kubectl apply -f jaeger/jaeger-collector.yaml
kubectl apply -f jaeger/jaeger-collector-service.yaml
kubectl apply -f jaeger/jaeger-query-config.yaml
kubectl apply -f jaeger/jaeger-query.yaml
kubectl apply -f jaeger/jaeger-query-service.yaml
```

5 - Aplique os novos objetos referentes ao monitoramento do Jaeger (Este passo só deve ser feito se seu ambiente conta com o Prometheus operator instalado)

```bash
kubectl apply -f jaeger/jaeger-monitor-collector.yaml
kubectl apply -f jaeger/jaeger-monitor-query.yaml
```

## :warning: Os passos abaixo devem ser feitos após a instalação do OpenTelemtry Agent nas aplicações

6 - Importe o dashboard presente em **dashboards/grafana/Jaeger-1617908489930.json** no seu grafana conforme explicado em roteiros anteriores (Este passo só deve ser feito se seu ambiente conta com o Prometheus operator instalado)

7 - Crie o indice **jaeger** no elastic search

7.1 - Acesse o Kibana e clique em **Manage**

![](../assets/imgs/jaeger-6-1.png)

7.2 - Clique em **Index Patterns**

![](../assets/imgs/jaeger-6-2.png)

7.3 - Clique em **Create Index Pattern**

![](../assets/imgs/jaeger-6-3.png)

7.4 - Em **Index pattern name** digite o valor `jaeger` e clique em **Next Step**

![](../assets/imgs/jaeger-6-4.png)

7.5 - Em **Time field** selecione o valor `startTimeMillis` e clique em **Create index pattern**

![](../assets/imgs/jaeger-6-5.png)

8 - Importe o dashboard do Kibana

8.1 - Acesse o Kibana e clique em **Manage**

![](../assets/imgs/jaeger-6-1.png)

8.2 - Clique em **Saved objects**

![](../assets/imgs/jaeger-7-2.png)

8.3 - Clique em **Import**

![](../assets/imgs/jaeger-7-3.png)

8.4 - Clique em **Import** novamente e selecione o arquivo localizado em **dashboard/kibana/Traces_SPI.ndjson** e por fim clique em **Import** mais uma vez.

![](../assets/imgs/jaeger-7-4.png)

8.5 - Clique em **Done**.

![](../assets/imgs/jaeger-7-5.png)

9 - Adicionando expurgo automático de métricas antigas

9.1 - Abra do arquivo **jaeger/jaeger-es-index-cleaner.yaml**, edite o cronjob de limpeza conforme os parâmetros desejados sendo eles:

![](../assets/imgs/CronJobJaeger.png)

- **1** - Expressão que determina o intervalo de execução do CronJob, deve ser definido conforme a [documentação do Kubernetes](https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/#cron-schedule-syntax), por padrão esse Job é executado às 02:00 am todos os dias.

- **2** - Define a quantidade máxima de dias que os traces devem permanecer disponíveis para consulta, o padrão são 7 dias, no caso da configuração padrão podemos entender que qualquer trace que tenha sido criado a mais de 7 dias será deletado quando o Job for executado.

- **3** - Define o endereço do servidor do elastic search

9.2 - Aplique o cronjob com o comando abaixo:

```bash
kubectl apply -f jaeger/jaeger-es-index-cleaner.yaml
```
