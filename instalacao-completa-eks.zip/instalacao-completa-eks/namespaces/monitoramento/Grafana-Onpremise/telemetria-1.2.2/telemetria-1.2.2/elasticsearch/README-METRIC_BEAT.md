<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

#  **INSTALAÇÃO E CONFIGURAÇÃO DO METRICBEAT**
 
O objetivo deste roteiro é instruir a instalação e configuração do **Metricbeat**.
### **PRÉ-REQUISITOS:**
- Instância do Elasticsearch instalada e em funcionamento;
- Kibana instalado e em funcionamento;
- Acesso ao usuário Root.
 
 
### **INSTALAÇÃO DO METRICBEAT**
 
Abra o seu navegador e acesse o endereço do seu Kibana complementando com a URL **app/home#/tutorial/elasticsearchMetrics** conforme exemplo abaixo:
 
```
http://kibana.autbank.net/app/home#/tutorial/elasticsearchMetrics
```
- Onde: http://endereco_do_seu_kibana/app/home#/tutorial/elasticsearchMetrics
 
 
Na página **Getting Started**, selecione o pacote de instalação **RPM**:
 
![](../assets/imgs/mb-1.png)
 
 
Esta página contém um tutorial de instalação do metricbeat disponibilizado pela Elasticsearch. Para instalar o metricbeat com as configurações testadas e homologadas, mantenha a pagina do tutorial aberta e continue seguindo os passos do **roteiro da Autbank**.
 
 
Acesse o seu servidor do Elasticsearch e em um terminal, mude para o usuário root:
 
```bash
sudo su
```
 
1 - Baixe e instale o Metricbeat
 
```bash
curl -L -O https://artifacts.elastic.co/downloads/beats/metricbeat/metricbeat-7.12.0-x86_64.rpm
 
rpm -vi metricbeat-7.12.0-x86_64.rpm
```
 
 
**2 - EDITAR A CONFIGURAÇÃO:**
 
2.1 - Abra o arquivo **metricbeat.yml** localizado em **/etc/metricbeat/metricbeat.yml**:
 
Neste exemplo, está sendo usado o editor de arquivos **nano**. Outros editores podem ser usados como por exemplo o **vi**.
 
```bash
nano /etc/metricbeat/metricbeat.yml
```
 
2.2 - Localize a seção **Elasticsearch Output** e modifique a propriedade **hosts** inserindo o valor **localhost:9200**. Não salve o arquivo ainda, siga para o proximo passo: 

2.3 - Na mesma seção, adicione o **username** **elastic** e a variável de ambiente **ES_PWD** para o **password**. Prossiga para o proximo passo:

2.4 - Adicione a propriedade **setup.kibana**, para definir as informações de conexão com o endereço do Kibana.

Exemplo das alterações no arquivo:

```yaml
# ---------------------------- Elasticsearch Output ----------------------------
output.elasticsearch:
  # Array of hosts to connect to.
  hosts: ["localhost:9200"]

  # Protocol - either `http` (default) or `https`.
  #protocol: "https"

  # Authentication credentials - either API key or username/password.
  #api_key: "id:api_key"
  username: "elastic"
  password: "${ES_PWD}"
setup.kibana:
 host: "kibana.dev.autbank.net:80"

```
 
2.5 No mesmo arquivo **metricbeat.yml**, localize a seção **Kibana** e edite a propriedade **host** informando o endereço do seu Kibana, conforme mostra exemplo abaixo:
 
```yaml
# =================================== Kibana ===================================
 
# Starting with Beats version 6.0.0, the dashboards are loaded via the Kibana API.
# This requires a Kibana endpoint configuration.
setup.kibana:
 
 # Kibana Host
 # Scheme and port can be left out and will be set to the default (http and 5601)
 # In case you specify and additional path, the scheme is required: http://localhost:5601/path
 # IPv6 addresses should always be defined as: https://[2001:db8::1]:5601
 host: "kibana.autbank.net:80"
 
 # Kibana Space ID
 # ID of the Kibana Space into which the dashboards should be loaded. By default,
 # the Default Space will be used.
 #space.id:
 
```
2.6 - Salve as alterações feitas no arquivo **metricbeat.yml**.

**3 - CRIAR UMA KEYSTORE PARA O METRICBEAT**


3.1 - Crie uma [keystore](https://www.elastic.co/guide/en/beats/metricbeat/current/keystore.html) para armazenar a **key** que será usada na autenticação do Metricbeat ao Elasticsearch:
 
```bash
metricbeat keystore create
```

3.2 - O próximo comando irá solicitar a digitação da senha do elasticsearch que foi definida anteriormente para o usuário **elastic**. Insira esta senha para que ela seja referenciada a variável de ambiente **ES_PWD** configurada ao arquivo *metricbeat.yml* nos passos anteriores:

```bash
metricbeat keystore add ES_PWD
```
- Para maiores informações sobre gerenciamento de keystore do metricbeat, consulte a documentação oficial do [elasticsearch](https://www.elastic.co/guide/en/beats/metricbeat/current/keystore.html) 

**4 - HABILITE E CONFIGURE O MÓDULO ELASTICSEARCH:**
 
4.1 - Habilitar Metricbeat:

```bash
metricbeat modules enable elasticsearch
```
 
4.2 - Iniciar o Metricbeat:
 
```bash
metricbeat setup
 
service metricbeat start
```
 
5 - Verificar o Status do módulo:
 
Na página do tuturial do Elasticsearch Metricbeat, verifique se os dados são recebidos do elasticsearch módulo Metricbeat clicando no botão **CHECK DATA**:
 
![](../assets/imgs/mb-2.png)
 
A mensagem abaixo indica que o metricbeat foi configurado com sucesso:
 
```
Data successfully received from this module
```
 
Clique no botão **DISCOVER** para verificar os dados no seu Kibana.
 
![](../assets/imgs/mb-3.png)