<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

#  **INSTALAÇÃO E CONFIGURAÇÃO DO ELASTICSEARCH**
 
O objetivo deste roteiro é instruir a instalação e configuração do **Elasticsearch** em um servidor Linux.
 
### **PRÉ-REQUISITOS:**
 
- Servidor dedicado para executar o Elasticsearch que atenda as especificações abaixo:

```
4 Cores 2Ghz
32 GB RAM
1 TB de HD (Considere usar um SSD ou Nvme para melhor performance)
```

- Dispositivo de armazenamento dedicado para salvar os dados do elasticsearch, instalado e montado como /mnt/es_data/ ;
- Distribuição Linux CentOS 7.x;
- Acesso ao usuário Root.
 
 
### **1 - CONFIGURAÇÕES INICIAIS DO CENTOS 7:**
 
Antes de instalar o Elasticsearch, é necessário que algumas configurações iniciais sejam feitas no sistema operacional:
 
1.1 - Em um terminal, troque o seu usuário para **root** com o comando:**
 
```bash
sudo su
```
 
1.2 - Instalar o firewalld, iniciar e ativar com os comandos abaixo:
 
```bash
yum install firewalld -y
 
systemctl start firewalld
 
systemctl enable firewalld
```
Verifique o status do firewalld:
 
```bash
systemctl status firewalld
```
1.3 - Liberar as portas do elasticsearch no firewall e após, reiniciar o firewall:
 
```bash
firewall-cmd --add-port=9200/tcp --permanent
 
firewall-cmd --add-port=9300/tcp --permanent
 
firewall-cmd --reload
```
 
1.4 - Desligar o SElinux:
 
```bash
setenforce 0
 
sed -i s/^SELINUX=.*$/SELINUX=disabled/ /etc/selinux/config
```
 
1.5 - Criar diretório de armazenamento dos dados e logs do elasticsearch:
 
- Neste ponto supõe que o dispositivo de armazenamento de dados dedicado ao elasticsearch esteja adicionado ao servidor, montado e mapeado como **/mnt/es_data/**.
 
Crie os diretórios necessários para o **data** e **log** do elasticsearch:
 
```bash
mkdir -p /mnt/es_data/lib/elasticsearch
 
mkdir -p /mnt/es_data/var/log/elasticsearch
```
Defina as permissões de acesso dos diretórios totalmente acessíveis para leitura/gravação:
 
```bash
chmod -R 777 /mnt/es_data
```
 
**2 - INSTALAR O ELASTICSEARCH**
 
A instalação do Elasticsearch deverá ser efetuada como usuário root.
 
2.1 - Importar a chave Elasticsearch GPG:
 
```bash
rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch
```
 
2.2 - Criar um arquivo chamado **elasticsearch.repo** em **/etc/yum.repos.d/** para adicionar o repositório elasticsearch e efetuar o download dos pacotes. Neste exemplo será usado o editor de arquivos **nano**. Outros editores podem ser usados como por exemplo o **vi**:
 
```bash
nano /etc/yum.repos.d/elasticsearch.repo
```
 
2.3) Copie o bloco abaixo e cole no arquivo a ser criado:
 
```
[elasticsearch]
name=Elasticsearch repository for 7.x packages
baseurl=https://artifacts.elastic.co/packages/7.x/yum
gpgcheck=1
gpgkey=https://artifacts.elastic.co/GPG-KEY-elasticsearch
enabled=0
autorefresh=1
type=rpm-md
```
Salve o arquivo.
 
2.4) Instalar o elasticsearch:
 
```bash
yum install --enablerepo=elasticsearch elasticsearch
```
 
2.5) Configurar o Elasticsearch para iniciar automaticamente quando o sistema for inicializado:
 
```bash
sudo /bin/systemctl daemon-reload
 
sudo /bin/systemctl enable elasticsearch.service
```
 
**3 - CONFIGURAR O ELASTICSEARCH**
 
Neste ponto, será efetuado as configurações de armazenamento dos dados do elasticsearch e a disponibilização do serviço na rede.
 
3.1 - Para configurar o armazenamento, abra o arquivo **elasticsearch.yml** localizado em **/etc/elasticsearch/elasticsearch.yml** e edite o **path.data** e **path.logs** localizados na seção **Paths** do arquivo, conforme exemplo abaixo:
 
```bash
nano /etc/elasticsearch/elasticsearch.yml
```
 
```yaml
# ----------------------------------- Paths ------------------------------------
#
# Path to directory where to store the data (separate multiple locations by comma):
#
path.data: /mnt/es_data/lib/elasticsearch
#
# Path to log files:
#
path.logs: /mnt/es_data/var/log/elasticsearch
#
```
 
Não salve o arquivo ainda.
 
 
3.2 - Para que o elasticsearch fique disponível em rede, é necessário expor o serviço. No mesmo arquivo **elasticsearch.yml**, localize as propriedades **network.host** e **http.port** na seção **Network** e edite conforme exemplo abaixo:
 
```yaml
# ---------------------------------- Network -----------------------------------
#
# By default Elasticsearch is only accessible on localhost. Set a different
# address here to expose this node on the network:
#
network.host: 0.0.0.0
#
# By default Elasticsearch listens for HTTP traffic on the first free port it
# finds starting at 9200. Set a specific HTTP port here:
#
http.port: 9200
#
# For more information, consult the network module documentation.
#
```
 
3.3 - Na seção **Discovery**, localize a propriedade **discovery.seed_hosts** e **acrescente** a propriedade **discovery.type** conforme o exemplo:
 
```yaml
# --------------------------------- Discovery ----------------------------------
#
# Pass an initial list of hosts to perform discovery when this node is started:
# The default list of hosts is ["127.0.0.1", "[::1]"]
#
discovery.type: single-node
discovery.seed_hosts: 127.0.0.1:9200
#
# Bootstrap the cluster using an initial set of master-eligible nodes:
#
#cluster.initial_master_nodes: ["node-1", "node-2"]
#
# For more information, consult the discovery and cluster formation module documentation.
#
```
 
Após as edições, salve o arquivo.
 
3.4 - Reinicie o elasticsearch para que as configurações sejam validadas:
 
```bash
sudo service elasticsearch restart
```
**4 - VERIFICAÇÕES**
 
4.1 - Verificar se o Elasticsearch está sendo executado localmente. No servidor do elasticsearch, rode o comando:
 
```bash
curl -X GET "localhost:9200/?pretty"
```
A saída do comando irá trazer informações do host e a seguinte mensagem no final:
 
```bash
 "tagline" : "You Know, for Search"
```
 
4.2 - Para verificar se o Elasticsearch está disponível a acesso externo, execute o comando abaixo a partir de uma outra máquina informando o endereço do seu elasticsearch conforme o exemplo:
 
```bash
curl -X GET "140.2.6.244:9200/?pretty"
```
 
A saída do comando irá trazer informações do host e a seguinte mensagem no final:
 
```
 "tagline" : "You Know, for Search"
```
 
4.3 - Para verificar o Health do Elasticsearch, execute o comando abaixo informando o endereço do seu elasticsearch, conforme mostra o exemplo:
 
```bash
curl -X GET "http://140.2.6.244:9200/_cluster/health/?pretty"
```
A saída do comando irá retornar as seguintes informações conforme mostra o exemplo abaixo:
 
```bash
{
 "cluster_name" : "elasticsearch",
 "status" : "yellow",
 "timed_out" : false,
 "number_of_nodes" : 1,
 "number_of_data_nodes" : 1,
 "active_primary_shards" : 10,
 "active_shards" : 10,
 "relocating_shards" : 0,
 "initializing_shards" : 0,
 "unassigned_shards" : 1,
 "delayed_unassigned_shards" : 0,
 "number_of_pending_tasks" : 0,
 "number_of_in_flight_fetch" : 0,
 "task_max_waiting_in_queue_millis" : 0,
 "active_shards_percent_as_number" : 90.9090909090909
}
```


**5 - ADICIONAR AUTENTICAÇÃO**

Por padrão o Elasticsearch é instalado inicialmente sem autenticação. Para adicionar essa camada de segurança é necessario habilitar este recurso. 

No processo, será necessário definir o password dos usuários [built-in](https://www.elastic.co/guide/en/elasticsearch/reference/current/built-in-users.html) que são usuários integrados do Elasticsearch e possuem um conjunto fixo de privilégios e não podem ser autenticados até que essas senhas sejam definidas. Os usuários built-in que terão o password definidos são:
 
- **elastic:** Super usuário  que possui todas as permissões ao elasticsearch.
 
- **kibana_system:** O usuário que o Kibana usa para se conectar e se comunicar com o Elasticsearch.
 
- **logstash_system:** O usuário Logstash usa ao armazenar informações de monitoramento no Elasticsearch.
 
- **beats_system:** O usuário que o Beats usa ao armazenar informações de monitoramento no Elasticsearch.
 
- **apm_system:** O usuário que o servidor APM usa ao armazenar informações de monitoramento no Elasticsearch.
 
- **remote_monitoring_user:** O usuário que Metricbeat usa ao coletar e armazenar informações de monitoramento no Elasticsearch. Ele tem as funções internas remote_monitoring_agente e remote_monitoring_collector.
 
:warning: Você não pode executar o comando **elasticsearch-setup-passwords** uma segunda vez, portanto guarde as senhas que serão definidas a seguir. Depois de definir uma senha para o elastic usuário, a senha de [bootstrap](https://www.elastic.co/guide/en/elasticsearch/reference/current/built-in-users.html#:~:text=When%20you%20install%20Elasticsearch%2C%20if,derived%20from%20a%20randomized%20keystore.) não é mais válida;


5.1 - Faça login no servidor do elasticsearch como **root** e acesse o diretório */usr/share/elasticsearch*:
 
```bash
cd /usr/share/elasticsearch
```
 
5.2 - Inicie o elasticsearch, caso estiver parado:
 
```bash
systemctl start elasticsearch
```


5.3 - Habilite a segurança editidanto o arquivo de configuração **elasticsearch.yml** localizado em **/etc/elasticsearch/elasticsearch.yml** e adicionando os parâmetros abaixo no final do arquivo:
 
```yaml
...
xpack.security.enabled: true
xpack:
 security:
   authc:
     realms:
       native:
         native1:
           order: 0
```
 
Onde:
 
- **xpack.security.enabled: true** - O valor *true* Define a segurança como habilitada e portanto o acesso ao elasticsearch somente poderá ser feito através de autenticação. O valor *false* desabilita.
 
- **xpack.security.authc.realms.native** - Define que o [realms](https://www.elastic.co/guide/en/elasticsearch/reference/current/realms.html) a ser usado na autenticação será o modo nativo (native) que é um domínio interno onde os usuários são armazenados em um indice Elasticsearch dedicado. Este realm suporta um token de autenticação na forma de nome de usuário e senha e é a maneira mais fácil de gerenciar e autenticar usuários.
 
- **xpack.security.authc.realms.native.native1** - Nome do realm nativo a ser usado. Default native1.
 
- **xpack.security.authc.realms.native.native1.order:0** - A prioridade do realm dentro da cadeia de realm. Realms com uma ordem inferior são consultados primeiro.
 
 
 
5.4 - Reinicie o elasticsearch e o serviço do elasticsearch para aplicar todas as alterações:
 
```bash
systemctl restart elasticsearch
 
systemctl restart elasticsearch.service
```


5.5 - Execute o utilitário **elasticsearch-setup-passwords**:
 
```bash
./bin/elasticsearch-setup-passwords interactive
```
 
5.6 - Será exibido a mensagem abaixo, confirme com **Y**:
 
![](../assets/imgs/elastic-user1.png)
 
 
 
5.7 - O prompt irá solicitar a inserção da senha para cada usuário built-in na sequência (guarde as senhas o processo não poderá ser refeito). Insira a senha escolhida, tecle enter e repita a senha para confirmar. Faça para todos os usuários que o prompt irá solicitar e aguarde a conclusão da definição de senha:
 
![](../assets/imgs/elastic-user2.png)
 
 

 
5.8 - Efetue um teste de conexão **localhost** fazendo uma request com o curl, por exemplo, ao elasticsearch para verificar se a autenticação foi efetivada com sucesso:
 
:warning: Neste teste o password do usuário elastic ficará visível pois será passado na request:
 
```bash
curl -u elastic:senha_do_elastic http://localhost:9200/_cluster/health/?pretty
```
Será retornada as informações do elasticsearch similar a imagem abaixo:
 
![](../assets/imgs/elastic-teste.png)

:warning: Para efetuar um teste externo, isto é, através de uma outra maquina na rede, substitua o endereço **localhost** para o endereço do elasticsearch na rede. Por exemplo: 
 
```bash
curl -u elastic:senha_do_elastic http://IP_ou_Hostname:9200/_cluster/health/?pretty
```