<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

# *Adição de Autenticação e Expurgo de Dados*


**1 - Adicionando autenticação**

**1.1 - Elasticsearch**
 
Será necessário definir o password dos usuários [built-in](https://www.elastic.co/guide/en/elasticsearch/reference/current/built-in-users.html) que são usuários integrados do Elasticsearch e possuem um conjunto fixo de privilégios e não podem ser autenticados até que essas senhas sejam definidas. Os usuários built-in que terão o password definidos são:
 
- **elastic:** Super usuário  que possui todas as permissões ao elasticsearch.
 
- **kibana_system:** O usuário que o Kibana usa para se conectar e se comunicar com o Elasticsearch.
 
- **logstash_system:** O usuário Logstash usa ao armazenar informações de monitoramento no Elasticsearch.
 
- **beats_system:** O usuário que o Beats usa ao armazenar informações de monitoramento no Elasticsearch.
 
- **apm_system:** O usuário que o servidor APM usa ao armazenar informações de monitoramento no Elasticsearch.
 
- **remote_monitoring_user:** O usuário que Metricbeat usa ao coletar e armazenar informações de monitoramento no Elasticsearch. Ele tem as funções internas remote_monitoring_agente e remote_monitoring_collector.
 
:warning: Você não pode executar o comando **elasticsearch-setup-passwords** uma segunda vez, portanto guarde as senhas que serão definidas a seguir. Depois de definir uma senha para o elastic usuário, a senha de [bootstrap](https://www.elastic.co/guide/en/elasticsearch/reference/current/built-in-users.html#:~:text=When%20you%20install%20Elasticsearch%2C%20if,derived%20from%20a%20randomized%20keystore.) não é mais válida;
 
1.1.1 - Faça login no servidor do elasticsearch como **root** e acesse o diretório */usr/share/elasticsearch*:
 
```bash
cd /usr/share/elasticsearch
```
 
1.1.2 - Inicie o elasticsearch, caso estiver parado:
 
```bash
systemctl start elasticsearch
```

1.1.3 - Habilite a segurança fazendo login no servidor do elasticsearch como **root** e edite o arquivo de configuração **elasticsearch.yml** localizado em **/etc/elasticsearch/elasticsearch.yml** e adicionando os parâmetros abaixo no final do arquivo:
 
```yaml
...
xpack.security.enabled: true
xpack:
 security:
   authc:
     realms:
       native:
         native1:
           order: 0
```
 
Onde:
 
- **xpack.security.enabled: true** - O valor *true* Define a segurança como habilitada e portanto o acesso ao elasticsearch somente poderá ser feito através de autenticação. O valor *false* desabilita.
 
- **xpack.security.authc.realms.native** - Define que o [realms](https://www.elastic.co/guide/en/elasticsearch/reference/current/realms.html) a ser usado na autenticação será o modo nativo (native) que é um domínio interno onde os usuários são armazenados em um indice Elasticsearch dedicado. Este realm suporta um token de autenticação na forma de nome de usuário e senha e é a maneira mais fácil de gerenciar e autenticar usuários.
 
- **xpack.security.authc.realms.native.native1** - Nome do realm nativo a ser usado. Default native1.
 
- **xpack.security.authc.realms.native.native1.order:0** - A prioridade do realm dentro da cadeia de realm. Realms com uma ordem inferior são consultados primeiro.


1.1.4 - Reinicie o elasticsearch e o serviço do elasticsearch para aplicar todas as alterações:
 
```bash
systemctl restart elasticsearch
 
systemctl restart elasticsearch.service
```
 

1.1.5 - Execute o utilitário **elasticsearch-setup-passwords**:
 
```bash
./bin/elasticsearch-setup-passwords interactive
```
 
1.1.6 - Será exibido a mensagem abaixo, confirme com **Y**:
 
![](../../assets/imgs/elastic-user1.png)
 
 
1.1.7 - O prompt irá solicitar a inserção da senha para cada usuário built-in na sequência (guarde as senhas o processo não poderá ser refeito). Insira a senha escolhida, tecle enter e repita a senha para confirmar. Faça para todos os usuários que o prompt irá solicitar e aguarde a conclusão da definição de senha:
 
![](../../assets/imgs/elastic-user2.png)
 
 
1.1.8 - Reinicie o elasticsearch e o serviço do elasticsearch para aplicar todas as alterações:
 
```bash
systemctl restart elasticsearch
 
systemctl restart elasticsearch.service
```
 
 
1.1.9 - Efetue um teste de conexão **localhost** fazendo uma request com o curl no servidor do elasticsearch, por exemplo, para verificar se a autenticação foi efetivada com sucesso:
 
:warning: Neste teste o password do usuário elastic ficará visível pois será passado na request:
 
```bash
curl -u elastic:senha_do_elastic http://localhost:9200/_cluster/health/?pretty
```
Será retornada as informações do elasticsearch similar a imagem abaixo:
 
![](../../assets/imgs/elastic-teste.png)
 
:warning: Para efetuar um teste externo, isto é, através de uma outra maquina na rede, substitua o endereço **localhost** para o endereço do elasticsearch na rede. Por exemplo: 
 
```bash
curl -u elastic:senha_do_elastic http://IP_ou_Hostname:9200/_cluster/health/?pretty
```

**1.2 - Kibana**
 
1.2.1 - Em um terminal, converta  a senha do usuário *kibana_sistem* em base 64 substituindo o valor *senha_kibana* para a senha definida anteriormente:
 
```bash
echo -n 'senha_kibana' | base64
```
 
1.2.2 - Copie o arquivo **kibana-secrets.yaml** localizado em *kibana/kibana-secrets.yaml* deste roteiro e cole no diretório onde se encontram os demais arquivos relacionados ao Kibana enviados anteriormente, abra e na propriedade *data* do arquivo, edite o valor da key **elasticsearch-password** substituindo a senha atual no arquivo para a senha em base 64 gerada no passo anterior e salve o arquivo.
 
 
1.2.3 - Aplique o arquivo de secret ao ambiente, lembrando de definir o terminal no contexto onde se encontram os arquivos do kibana:
 
```bash
kubectl apply -f kibana-secrets.yaml
```
 
1.2.4 - Abra o arquivo **kibana.yaml** do seu ambiente, enviado anteriormente, e na propriedade **env** adicione as variáveis de ambiente **ELASTICSEARCH_USERNAME** e **ELASTICSEARCH_PASSWORD** para autenticação do kibana no elasticsearch usando o secret criado no passo anterior, conforme exemplo:
 
```yaml
...
env:
  - name: ELASTICSEARCH_USERNAME
    valueFrom:
      secretKeyRef:
        key: elasticsearch-user
        name: kibana-secrets
  - name: ELASTICSEARCH_PASSWORD
    valueFrom:
      secretKeyRef:
        key: elasticsearch-password
        name: kibana-secrets
...
```
1.2.5 - Salve o arquivo e aplique ao ambiente usando o comando kubectl:
 
```bash
kubectl apply -f kibana.yaml
```
 
**1.3 - Metricbeat**
 
1.3.1 - Acesse o servidor do elasticsearch com o usuário **root** e crie uma [keystore](https://www.elastic.co/guide/en/beats/metricbeat/current/keystore.html) para armazenar a **key** que será usada na autenticação do Metricbeat ao Elasticsearch:
 
```bash
metricbeat keystore create
```
1.3.2 - O próximo comando irá solicitar a digitação da senha do elasticsearch que foi definida anteriormente para o usuário **elastic**. Insira esta senha para que ela seja referenciada a variável de ambiente **ES_PWD**:
 
```bash
metricbeat keystore add ES_PWD
```
 
1.3.4 - Abra o arquivo **metricbeat.yml** localizado em */etc/metricbeat/metricbeat.yml* e edite o arquivo adicionando o username **elastic** e a variável de ambiente **ES_PWD** do password ao arquivo conforme mostra abaixo:
 
![](../../assets/imgs/metricbeat-file1.png)
 
1.3.5 - Salve o arquivo e aplique as alterações com o comando:
 
```bash
metricbeat setup
service metricbeat start
```
 
Para maiores informações sobre gerenciamento de keystore do metricbeat, consulte a documentação oficial do [elasticsearch](https://www.elastic.co/guide/en/beats/metricbeat/current/keystore.html)
 
 
**1.4 - Filebeat**
 
1.4.1 - Em um terminal, converta  a senha do usuário *elastic* em base 64 substituindo o valor *senha_elastic* para a senha definida anteriormente:
 
```bash
echo -n 'senha_elastic' | base64
```
 
1.4.2 - Copie o arquivo **filebeat-secrets.yaml** localizado em *filebeat/filebeat-secrets.yaml* deste roteiro, cole no diretório onde se encontram os demais arquivos relacionados ao filebeat enviados anteriormente, abra e na propriedade *data* do arquivo, edite o valor da key **elasticsearch-password** substituindo a senha atual no arquivo para a senha em base 64 gerada no passo anterior e salve o arquivo.
 
 
1.4.3 - Aplique o arquivo de secret ao ambiente, lembrando de definir o terminal no contexto onde se encontram os arquivos do filebeat:
 
```bash
kubectl apply -f filebeat-secrets.yaml
```
 
1.4.4 - Abra o arquivo **filebeat.settings.configmap.yml** do seu ambiente, enviado anteriormente, e na propriedade **data.filebeat.yml.output.elasticsearch** adicione os parâmetros **username** e **password** seguidos das variáveis de ambiente  **ELASTICSEARCH_USERNAME** e **ELASTICSEARCH_PASSWORD** respectivamente, conforme exemplo:
 
```yaml
...
data:
 filebeat.yml: |-
...
   output.elasticsearch:
     hosts: ['${ELASTICSEARCH_HOST:elasticsearch}:${ELASTICSEARCH_PORT:9200}']
     username: ${ELASTICSEARCH_USERNAME}
     password: ${ELASTICSEARCH_PASSWORD}
```
 
1.4.5 - Salve e aplique o arquivo ao ambiente, lembrando de definir o terminal no contexto onde se encontram os arquivos do filebeat:
 
```bash
kubectl apply -f filebeat.settings.configmap.yml
```
 
 
1.4.6 - Abra o arquivo **filebeat.daemonset.yml** do seu ambiente, enviado anteriormente, e na propriedade **env** e adicione as variáveis de ambiente **ELASTICSEARCH_USERNAME** e **ELASTICSEARCH_PASSWORD** para autenticação do filebeat no elasticsearch usando o secret criado no passo anterior, conforme exemplo:
 
```yaml
...
env:
  - name: ELASTICSEARCH_USERNAME
    valueFrom:
      secretKeyRef:
        key: elasticsearch-user
        name: filebeat-secrets
  - name: ELASTICSEARCH_PASSWORD
    valueFrom:
      secretKeyRef:
        key: elasticsearch-password
        name: filebeat-secrets
...
```
 
1.4.7 - Salve e aplique o arquivo ao ambiente, lembrando de definir o terminal no contexto onde se encontram os arquivos do filebeat:
 
```bash
kubectl apply -f filebeat.daemonset.yml
```
 
**1.5 - Jaeger**
 
1.5.1 - Em um terminal, converta  a senha do usuário *elastic* em base 64 substituindo o valor *senha_elastic* para a senha definida anteriormente:
 
```bash
echo -n 'senha_elastic' | base64
```
 
1.5.2 - Copie o arquivo **jaeger-secrets.yaml** localizado em *jaeger/jaeger-secrets.yaml* deste roteiro, cole no diretório onde se encontram os demais arquivos relacionados ao jaeger enviados anteriormente, abra e na propriedade *data* do arquivo, edite o valor da key **elasticsearch-password** substituindo a senha atual no arquivo para a senha em base 64 gerada no passo anterior e salve o arquivo.

1.5.3 - Para acessar o Jaeger Query precisaremos gerar um usuário e senha no formato [`.htpasswd`](https://pt.wikipedia.org/wiki/.htpasswd) para isso podemos usar uma das duas formas a seguir:

1.5.3.1 - Abra o site [https://www.web2generators.com/apache-tools/htpasswd-generator](https://www.web2generators.com/apache-tools/htpasswd-generator), adicione o usuário e senha que deseja para o acesso ao Jaeger Query e clique em *Generate .htpasswd file* e copie o valor presente em *Output*.

![](../../assets/imgs/jaeger-1-2.png)

**Caso opte por essa forma pule o passo 1.5.3.2**

1.5.3.2 - Como alternativa podemos instalar o `httpd-tools` para gerar o hash, execute os comandos abaixo substituindo *admin* e *password* pelo usuário e senha que deseja para o acesso ao Jaeger Query e copie a saída do comando.

```bash
yum install httpd-tools -y

htpasswd -n -b admin password
```

1.5.4 - Crie um base64 do htpasswd com o comando abaixo, substituindo `htpasswd` pelo valor gerado no passo anterior:

```bash
echo -n 'htpasswd' | base64
```

1.5.5 - Abra o arquivo **jaeger/jaeger-secrets.yaml** e na propriedade *data* do arquivo, edite o valor da key **jaeger-auth** substituindo o valor pelo htpasswd em base64 gerado no passo anterior e salve o arquivo.
 
1.5.6 - Aplique o arquivo ao ambiente, lembrando de definir o terminal no contexto onde se encontram os arquivos do jaeger:
 
```bash
kubectl apply -f jaeger-secrets.yaml
```
 
1.5.7 - Abra o arquivo **jaeger-collector.yaml** do seu ambiente, enviado anteriormente, e na propriedade **env** adicione as variáveis de ambiente **ES_USERNAME** e **ES_PASSWORD** para autenticação do jaeger-collector no elasticsearch usando o secret criado no passo anterior,conforme exemplo:
 
```yaml
env:
...
  - name: ES_USERNAME
    valueFrom:
      secretKeyRef:
        key: elasticsearch-user
        name: jaeger-secrets
  - name: ES_PASSWORD
    valueFrom:
      secretKeyRef:
        key: elasticsearch-password
        name: jaeger-secrets
...
```
 
1.5.8 - Salve o arquivo e aplique ao ambiente usando o comando kubectl:
 
```bash
kubectl apply -f jaeger-collector.yaml
```
 
1.5.9 - Abra o arquivo **jaeger/jaeger-query.yaml** ajustando o endereço do elastic search de acordo com sua instalação

```yaml
args:
  - "--es.server-urls=http://172.31.84.27:9200"
```

 
1.5.10 - Salve o arquivo e aplique os seguintes arquivos ao seu ambiente:
 
```bash
kubectl apply -f jaeger-query-config.yaml
kubectl apply -f jaeger-query.yaml
```
 
 
**1.6 - Criar usuário no Kibana**
 
1.6.1 - Acesse a interface do Kibana e faça login com o usuário **elastic** informando a senha definida anteriormente:
 
![](../../assets/imgs/kibana-user1.png)
 
 
1.6.2 - Clique em **Manage**:
 
 
![](../../assets/imgs/kibana-user2.png)
 
 
1.6.3 - Em **Security**, clique em **Users**:
 
 
![](../../assets/imgs/kibana-user3.png)
 
 
1.6.4 - Será exibido os usuários **built-in** do elasticsearch. Para adicionar um novo usuário clique em **Create user**:
 
 
![](../../assets/imgs/kibana-user4.png)
 
 
1.6.5 - Adicione as informações de login para o novo usuário conforme exemplo:
 
 
![](../../assets/imgs/kibana-user4-a.png)
 
 
1.6.6 - Mais abaixo, em **Privileges**, na lista de **Roles**, selecione a role **kibana_admin** e em seguida clique **Create User**
 
 
![](../../assets/imgs/kibana-user4-b.png)
 
 
- O usuario criado será mostrado na lista de usuários.
 
- A role definida para este usuário tem a permissão de administrador do Kibana (kibana_admin). Para mais informações, consulte a documentação o oficial sobre as [built-in-roles](https://www.elastic.co/guide/en/elasticsearch/reference/current/built-in-roles.html)
 
- Caso for necessario criar novas roles, consulte a documentação oficinal sobre [kibana-role-management](https://www.elastic.co/guide/en/kibana/current/kibana-role-management.html#_required_permissions_9).


**2 - Adicionando expurgo automático de traces antigos**

2.1 - Abra o arquivo **jaeger/jaeger-es-index-cleaner.yaml**, edite o cronjob de limpeza conforme os parâmetros desejados sendo eles:

![](../../assets/imgs/CronJobJaeger.png)

- **1** - Expressão que determina o intervalo de execução do CronJob, deve ser definido conforme a [documentação do Kubernetes](https://kubernetes.io/docs/concepts/workloads/controllers/cron-jobs/#cron-schedule-syntax), por padrão esse Job é executado às 02:00 am todos os dias.

- **2** - Define a quantidade máxima de dias que os traces devem permanecer disponíveis para consulta, o padrão são 7 dias, no caso da configuração padrão podemos entender que qualquer trace que tenha sido criado a mais de 7 dias será deletado quando o Job for executado.

- **3** - Define o endereço do servidor do elastic search

2.2 - Aplique o cronjob com o comando abaixo:

```bash
kubectl apply -f jaeger/jaeger-es-index-cleaner.yaml
```

**3 - Configurando expurgo automático de logs antigos**
 
 :warning: É importante deixar claro que esse procedimento irá por padrão deletar todos os índices de logs com idade superior a 15 dias por padrão, você pode escolher outras configurações baseado na [doc oficial do IML](https://www.elastic.co/guide/en/elasticsearch/reference/7.12/index-lifecycle-management.html).

3.1 - Acesse o Kibana e clique em **Manage**

![](../../assets/imgs/jaeger-6-1.png)

3.2 - Clique em **Index Lifecycle Policies**

![](../../assets/imgs/logs-3-2.png)

3.3 - Clique na política **Filebeat**

![](../../assets/imgs/logs-3-3.png)

3.4 - Clique sobre o ícone da **lixeira**

![](../../assets/imgs/logs-3-4.png)

3.5 - Clique na opção **Advanced Settings**, desmarque a opção **Use recommended defaults** e configure o **Maximum index size** e **Maximum age** conforme a imagem abaixo:

![](../../assets/imgs/logs-3-5.png)

3.6 - Altere o campo **Move data into phase when:** para 15 e clique em **Save Policy**

![](../../assets/imgs/logs-3-6.png)