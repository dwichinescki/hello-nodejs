<div style="background-color: red; padding-top: 7px;">
  <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAANIAAAArCAYAAAANBNaTAAAACXBIWXMAAA7EAAAOxAGVKw4bAAAHFUlEQVR4nO1c21EcORQ92tpvaiJgicBmE8CzCQzeBHgkwCOBoXAC4E1gwAl47QTwOgEoJzDsJgDlBM5+SGM3Pa3WkVrdzFA6VRTFIN0raXTftxsoKCgoKCgoKCgoKCgoKCgoKCgoWC2YLpNJbgD4JAy9MMZ8TqD/CsD7tjHGmD9i6TraUwBJcz2YGWM+1HhMAJy6P+8APHTk8QjgyhjzvSOdJbi1bof4G2P+ysRvE8BbACP30V3iHZmGxhhj3om0jirr8SHbGVQZT6nhwQldLP2dEOEOa99068qJvQY+s8w85rQKJhtIblA/i0kGfnsefnM2nGGAVhAinaOh9l9nvCkyXuAigUdvguTov+J6ClMjnw7nELO+JKVY4TUReNxSVBbKggUaqlL9mLrvNuYzZRM17ETy6FWQHI8+hGlJazG/MD0wg2Wi3X8sopWi4xVj+R4o3BeFkEDjViAzZwcF4mMcvOAe3ObmE0lv0/N5bmFqvOTML0w3Mfv37P0mkXeUUnS8VPepilZloRAIzFfDk+j9BsH0wyeF4LDCJ7cgTUnOPP9bV2FKtkrU3CwfopSi43eTwKfV8ioEWuaq1jjJAocOYy/hMKp4oMcyNPDqQ5BIa8qXzDTXU5iSYyVad6ULZKXo+N0k8vFaXmWyZ94Gtf3PKbh0v0QexAaA85g5DRgBuO5IIxV37vc2gH/qB2SM+QbgDWyaOQdGjs8TxWGMOQRwlYnHVsok2lRv0twKTut76wljZkyuOJxD2/9+9nIDdX9SQTCNyPwWqU5vKMvk4zPLQDv6gjEu6A9BjtPYLSRozBYqExvmqC6t7NL9GnEIG/hZXMyBa5K/BaR9nJFfExaWadcY89/iQ2PMN5JvYAuGCxwirMHuATTGYLB7eVJwNMYccjlm24bVlqHCYJVnLGLohzAmOUkppkZiBLvuTnfQ3WPFI7oHcNaFl28BM1GKp9TSiUGJp2ABI/fgs3DBVDI1bdo5i+Z4XYjnF53+p17/e2Dmgju7WaQFNms0g0hcQ1SWToqRaC/ZgTD0HsAlgH2R/wkzV+kTsYhlVmEtgN5K9HcC7daWqwrOXGvNF2HswloMgeT4mjYuHAtDL40xX1P5tC1AleK9yhxVm3nTqAqNyH2EYi6vZeKwFumjwIvsocDtMK/MielgyWHVFUwqNINw49S4d86EwmvQItF+WWOB1pdq06bTZnct4xfYptUUq4ARnsZFg4M2ZlLW8CVBa6rW6IdH4WJHNVYYKhv7PuGyX0OLC5OydIprpx5O02GrLt45h0mjrjRo6zIH4vCoIiGttxDq7gYaBHRApai6qlsATlSi7lyVvffm0qktHb5MVYyLt9QQqMyN3I/i2jQWGTmQa8e4Nhop9c24dHdbG5UCb8Gd4TOcMq7Esulotv2oia85c/fSRR5+sFOBegV9Upu3toKkrJ2eGIcRWTsKwiSuhcyQRXVo7JKmIEhu3LwLnwa+vcScVbS5dmqt4aJag/FAdfFSfN8XB2PMKbRsGWDrcd4LQKvklNrLIwKxUISL95bdnttR78tb8fLvQ+tW+ZR6/xoFyR2+4oPew6a7W+H8zuA4WN93qDTqqiOmGNh2AVSFeCYG2b0rxYj7AggxvNvXrkAruX3NZ5Fiag1qhuMMWhV+VWpLz42tiLEjNCg+p60PhPn36uPTrh9xCKWo3pctao+bf4WmnLpaUwtGPGuUQFvtHL9x47u0+afCFyPNhLmxMdKMPwPsxc+E/kex2zBvWPONODf28e6Y5MWryrzQeqY1PupdlJ/aFdawoBeVRW7qtZN7mWiLqVXf88cLQNj84hIlBQnY/q0dY8xnkvsYtlvcFwMsXdQMOMhIa6v6hzv/sTj3lOST+dUXhtAKWvX/v0Pv1TsH8Kc49gmMMV9JXiIcZoxg79qhQHYXwL9oX//CxZNfjtMkSDHNjHXBqKZ/R8jQdGqM+UBr/IYQpv0Bmi97g1M+izpI7PdY/y6rb945RPp32bU59gxW4YToHJCchepAxpjvTjmH3n41JnmkurxRzyM9F5yVU4PcVOzXX6dV8PxwMbic4BBpfoYW572nGK+vhSABvQtTEaIVhrv4StfDNsV4z5UYlFS+5AmtjSABvQnTZRGitYBaC4pJu+8KNLfrSZAmrJUgAdmF6cppppcCRcOuJSJcPPmRDtdIoNA8Z6Dw2yRIq/BlPKKlhpBJmK7cuxNeCo5rNb1HpL97Itc7K4CM9ynCxTtR09eO5pUw9LrN0i0JktPQx8oiesIjgDehtqOOwvTShOiqnl3q+CKXXJe/D4uvungHETSPEd7zFlosXaNr574UdcE5cQfgtbsEQSQK00sSonsAu779uHN8jefxMs76OGdndZUOBfnuVtzG0JwT5n73d0FBQUFBQUFBQUFBQUFBQUFBQUFBQcHq4n/+NAzHgESOdwAAAABJRU5ErkJggg==
" alt="Logotipo">
</div>

#  **MONITORAMENTO KAFKA**

Este roteiro descreve os passos para a inclusão do monitoramento do Kafka.

Execute os comandos descritos nos passos a seguir a partir do diretório raiz deste roteiro.

### Pré requisitos:

- Prometheus e Grafana em funcionamento no cluster;
- Pasta Autbank criada no Grafana;
- Ferramenta de comando Kubectl instalada.

## **Instalação dos serviços do Kafka Exporter**

Aplique ao ambiente o arquivo **servicemonitor.yaml** e o arquivo **kafka-exporter-service.yaml** do kafka exporter com os comandos:

```bash
kubectl apply -f servicemonitor.yaml
```

```bash
kubectl apply -f kafka-exporter-service.yaml
```

## **Instalação do Kafka Exporter**

Edite o arquivo **kafka-exporter-deployment.yaml** informando o endereço dos **kafka.server** do seu ambiente conforme o exemplo abaixo:

```yaml
 name: kafka-exporter
          args:
            - --kafka.server=kafka1:9094
            - --kafka.server=kafka2:9094
            - --kafka.server=kafka3:9094
            - --sasl.username=$(KAFKA_BROKER_USER)
            - --sasl.password=$(KAFKA_BROKER_PASSWORD)
            - --sasl.enabled
```

Faça o deploy do **kafka exporter** com comando:

```bash
kubectl apply -f kafka-exporter-deployment.yaml
```

## Importar a Dashboard Kafka Exporter para o Grafana

Faça a importação da dashboard **kafka-exporter-overview_rev5** para o **Grafana** do seu ambiente executando os passos abaixo:

Acesse interface do seu grafana disponível em  http://[endereco-grafana]:[porta], conforme exemplo abaixo:

```
http://140.2.6.243:30123/
```

Para adicionar a dashboard, clique no icone **+** e no menu selecione **import**:

![](imagens/import-dashboard-1.png)

Clique em **Upload .json file** navegue até o diretório **dashboard** deste roteiro e escolha o arquivo **kafka-exporter-overview_rev5.json**.

![](imagens/import-dashboard-2.png)

Em 'Options > Folder' selecione **Autbank** e em 'Rancher_Monitoring' selecione **Prometheus** e clique em **Import**:

![](imagens/import-dashboard-3.png)

## **Kafka Exporter Overview**

Essa dashboard irá mostrar os dados dos kafkas nos namespaces correspondentes. As informações são:

- Message in per secound;

- Lag by Consumer Group;

- Message in per minute;

- Message consume per minute;

- Partitions per Topic.


### **Message in per secound**

Mostra a quantidade de mensagens entrando nos tópicos Kafka por segundo:

![](imagens/message-in-per-second.png)


### **Lag by Consumer Group**

Exibe o atraso de consumo por Consumer Group

![](imagens/lag-by-consumer-group.png)

### **Message in per minute**

Quantidade de mensagens entrando nos tópicos kafka por minuto

![](imagens/message-in-per-minute.png)

### **Message consume per minute**

Quantidade de mensagens consumidas por minuto

![](imagens/message-consume-por-minute.png)

### **Partitions per Topic**

Quantidade de partições por tópico

![](imagens/partitions-per-topic.png)


## **OUTRAS DASHBOARDS DE MONITORAMENTO DO KAFKA**

## Monitoramento de recursos de Hardware

Para monitorar o uso de **memória**, **cpu** e demais informações, na interface do Grafana, acesse a seguinte dashboard que já está disponível no Grafana como padrão:

- Clique na lupa para pesquisar;

![](imagens/kafka-hardware-2.png)

- Pesquise a dashboard (digite com espaços nas barras): Kubernetes / Compute Resources / Workload

- Clique em: Kubernetes / Compute Resources / Workload

![](imagens/kafka-hardware-3.png)


Selecione o **namespace** e o **workload do Kafka** conforme o exemplo abaixo:

![](imagens/kafka-hardware-4.png)

Neste exemplo, serão mostrados os gráficos de consumo do Workload do **Kafka-1**. Para monitorar as outras instâncias do Kafka, basta mudar o Workload neste menu. 
Os principais dados disponíveis são:


- CPU Usage;

- Memory Usage.

## CPU Usage (uso de CPU);

![](imagens/kafka-hardware-5.png)

## Memory Usage (uso de memória)

![](imagens/kafka-hardware-6.png)